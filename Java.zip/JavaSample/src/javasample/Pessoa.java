/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javasample;

/**
 *
 * @author Davi Oliveira Ra: 081180006
 */
public class Pessoa {
        
    private String nome;
    private char genero;
    private int idade;
    
    public  Pessoa (String nome, int idade, char genero){
        this.nome = nome;
        this.idade = idade;
        this.genero = genero;
    }
      /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    public int getIdade() {
        return idade;
    }

    /**
     * @param idade the nome to set
     */
    public void setIdade(int idade) {
        this.idade = idade;
    }
      /**
     * @return the nome
     */
    public String getGenero() {
        return nome;
    }

    /**
     * @param genero the nome to set
     */
    public void setGenero(char genero) {
        this.genero = genero;
    }
    public void dizerOla(Pessoa outraPessoa){
        if(outraPessoa.idade < 60)
        {
            System.out.println(this.nome + ": Olá, meu nome é: "+ this.nome +"! Eu tenho " + this.idade + " anos. E você?");
            outraPessoa.responderOla(this);
        }
        else {
            if('M' == outraPessoa.genero)
            {
                System.out.println(this.nome + ": Olá, Senhor meu nome é: "+ this.nome +"! Eu tenho " + this.idade + " anos. E o Senhor?");
                outraPessoa.responderOla(this);
            } else {
                System.out.println(this.nome + ": Olá, Senhora meu nome é: "+ this.nome +"! Eu tenho " + this.idade + " anos. E a Senhora?");
                outraPessoa.responderOla(this);
            }
        }
    }

    public void responderOla(Pessoa outraPessoa){
        if(outraPessoa.idade < 60)
        {
            System.out.println(this.nome + ": Olá, meu nome é: "+ this.nome +"! Eu tenho " + this.idade + " anos");
        }
        else {
            if('M' == outraPessoa.genero)
            {
                System.out.println(this.nome + ": Olá Senhor, meu nome é: "+ this.nome +"! Eu tenho " + this.idade + " anos");
            } else {
                System.out.println(this.nome + ": Olá Senhora, meu nome é: "+ this.nome +"! Eu tenho " + this.idade + " anos");
            }
        }
    }
  
    public void Saudação(Pessoa outraPessoa){
        System.out.println(this.nome + ": Tudo bem com você?");
        outraPessoa.responderSaudação(this);
    }
    
    public void responderSaudação(Pessoa outraPessoa){
        System.out.println(this.nome + ": Ahh, " + outraPessoa.getNome() + " estou bem na medida do possível, e você?");
    }
    public void Sentimento(Pessoa outraPessoa){
        System.out.println(this.nome + ": Estou bem, mas o que aconteceu com você " + outraPessoa.getNome()+ "?");
        outraPessoa.responderSentimento(this);
    }
    public void responderSentimento(Pessoa outraPessoa){
        System.out.println(this.nome + ": Toda essa situação do covid está me deixando muito mal, mas logo isso vai passsar");
    }
}
