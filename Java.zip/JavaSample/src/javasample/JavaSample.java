/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javasample;

//import java.util.*;

/**
 *
 * @author Davi Oliveira Ra: 081180006
 */
public class JavaSample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pessoa leticia = new Pessoa("Leticia", 19, 'F' );
        Pessoa davi = new Pessoa("Davi",20 , 'M');
        leticia.dizerOla(davi);
        leticia.Saudação(davi);
        leticia.Sentimento(davi);

        
    }
    
    
    
}
